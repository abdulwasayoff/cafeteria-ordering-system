from flask import Flask, request, jsonify
from flask_cors import CORS
import hashlib
import json
import uuid
from datetime import datetime, timedelta
import random

app = Flask(__name__)
app.secret_key = 'campus-hub-premium-2025-secret'
CORS(app, supports_credentials=True, origins=['http://localhost:8000'])

# ========== DATABASE ==========
users_db = {}
menu_items = []
orders = []
cart = {}
sessions = {}
offers = []

# ========== INITIALIZE DATA ==========
def init_data():
    print("🚀 Initializing CampusHub Premium Cafeteria...")
    
    # ===== USERS =====
    users_db['admin'] = {
        'id': 1,
        'username': 'admin',
        'password_hash': hashlib.sha256('admin123'.encode()).hexdigest(),
        'email': 'admin@campushub.com',
        'role': 'admin',
        'balance': 1000.00,
        'profile_pic': '👑',
        'phone': '+92 300 1234567',
        'address': 'Admin Block, PAF-IAST'
    }
    
    users_db['student1'] = {
        'id': 2,
        'username': 'student1',
        'password_hash': hashlib.sha256('password123'.encode()).hexdigest(),
        'email': 'student1@campushub.com',
        'role': 'student',
        'balance': 500.00,
        'profile_pic': '👨‍🎓',
        'phone': '+92 300 7654321',
        'address': 'Hostel Block A, Room 101'
    }
    
    users_db['teacher1'] = {
        'id': 3,
        'username': 'teacher1',
        'password_hash': hashlib.sha256('teacher123'.encode()).hexdigest(),
        'email': 'teacher@campushub.com',
        'role': 'teacher',
        'balance': 800.00,
        'profile_pic': '👨‍🏫',
        'phone': '+92 300 1122334',
        'address': 'Faculty Quarters, Block C'
    }
    
    users_db['kitchen1'] = {
        'id': 4,
        'username': 'kitchen1',
        'password_hash': hashlib.sha256('kitchen123'.encode()).hexdigest(),
        'email': 'kitchen@campushub.com',
        'role': 'kitchen_staff',
        'balance': 0.00,
        'profile_pic': '👨‍🍳',
        'phone': '+92 300 4455667',
        'address': 'Kitchen Area, Cafeteria'
    }
    
    # ===== MENU ITEMS =====
    global menu_items
    menu_items = [
        # Breakfast
        {
            'id': 1,
            'name': 'Paratha with Omelette',
            'description': 'Freshly made paratha served with fluffy omelette',
            'category': 'Breakfast',
            'price': 180.00,
            'image': 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=400&h=300&fit=crop',
            'rating': 4.8,
            'prep_time': 10,
            'calories': 450,
            'tags': ['Vegetarian', 'Popular'],
            'customizations': ['Extra Omelette', 'Butter', 'Pickle']
        },
        {
            'id': 2,
            'name': 'Halwa Puri',
            'description': 'Traditional breakfast with semolina halwa and puri',
            'category': 'Breakfast',
            'price': 220.00,
            'image': 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=400&h=300&fit=crop',
            'rating': 4.9,
            'prep_time': 15,
            'calories': 550,
            'tags': ['Vegetarian', 'Special'],
            'customizations': ['Extra Halwa', 'Chickpeas']
        },
        {
            'id': 3,
            'name': 'Lahori Channay',
            'description': 'Spicy chickpeas with traditional Lahori spices',
            'category': 'Breakfast',
            'price': 150.00,
            'image': 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop',
            'rating': 4.7,
            'prep_time': 12,
            'calories': 320,
            'tags': ['Vegetarian', 'Spicy'],
            'customizations': ['Extra Spicy', 'With Puri']
        },
        {
            'id': 4,
            'name': 'Masala Chai',
            'description': 'Traditional Pakistani tea with spices',
            'category': 'Breakfast',
            'price': 80.00,
            'image': 'https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?w=400&h=300&fit=crop',
            'rating': 4.6,
            'prep_time': 5,
            'calories': 60,
            'tags': ['Beverage', 'Hot'],
            'customizations': ['Less Sugar', 'Extra Milk']
        },
        
        # Desi Food
        {
            'id': 5,
            'name': 'Chicken Karahi',
            'description': 'Spicy chicken cooked in traditional karahi',
            'category': 'Desi Food',
            'price': 450.00,
            'image': 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&h=300&fit=crop',
            'rating': 4.9,
            'prep_time': 25,
            'calories': 650,
            'tags': ['Non-Veg', 'Spicy', 'Special'],
            'customizations': ['Extra Spicy', 'With Naan', 'Boneless']
        },
        {
            'id': 6,
            'name': 'Biryani',
            'description': 'Fragrant rice with tender chicken and spices',
            'category': 'Desi Food',
            'price': 350.00,
            'image': 'https://images.unsplash.com/photo-1563379091339-03246963d9d6?w=400&h=300&fit=crop',
            'rating': 4.8,
            'prep_time': 30,
            'calories': 720,
            'tags': ['Non-Veg', 'Rice', 'Popular'],
            'customizations': ['Extra Raita', 'With Salad', 'Spicy']
        },
        {
            'id': 7,
            'name': 'Daal Mash',
            'description': 'Creamy black lentils cooked overnight',
            'category': 'Desi Food',
            'price': 180.00,
            'image': 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop',
            'rating': 4.5,
            'prep_time': 20,
            'calories': 280,
            'tags': ['Vegetarian', 'Healthy'],
            'customizations': ['With Butter', 'Extra Cream']
        },
        {
            'id': 8,
            'name': 'Seekh Kabab',
            'description': 'Minced meat kababs with traditional spices',
            'category': 'Desi Food',
            'price': 320.00,
            'image': 'https://images.unsplash.com/photo-1594041680534-e8c8cdebd659?w=400&h=300&fit=crop',
            'rating': 4.7,
            'prep_time': 18,
            'calories': 420,
            'tags': ['Non-Veg', 'BBQ', 'Appetizer'],
            'customizations': ['Extra Spicy', 'With Chutney']
        },
        
        # Fast Food
        {
            'id': 9,
            'name': 'Zinger Burger',
            'description': 'Crispy chicken burger with special sauce',
            'category': 'Fast Food',
            'price': 320.00,
            'image': 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop',
            'rating': 4.6,
            'prep_time': 12,
            'calories': 580,
            'tags': ['Non-Veg', 'Popular'],
            'customizations': ['Extra Cheese', 'Extra Sauce', 'No Mayo']
        },
        {
            'id': 10,
            'name': 'Cheese Pizza',
            'description': '12-inch pizza with mozzarella cheese',
            'category': 'Fast Food',
            'price': 650.00,
            'image': 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop',
            'rating': 4.7,
            'prep_time': 20,
            'calories': 850,
            'tags': ['Vegetarian', 'Italian'],
            'customizations': ['Extra Cheese', 'Extra Toppings', 'Thin Crust']
        }
    ]
    
    # ===== OFFERS =====
    global offers
    offers = [
        {
            'id': 1,
            'code': 'STUDENT20',
            'title': 'Student Special',
            'description': '20% off for all students',
            'discount_type': 'percentage',
            'value': 20,
            'min_order': 300,
            'valid_until': '2025-12-31'
        },
        {
            'id': 2,
            'code': 'FIRSTORDER',
            'title': 'First Order',
            'description': '15% off on first order',
            'discount_type': 'percentage',
            'value': 15,
            'min_order': 500,
            'valid_until': '2025-12-31'
        },
        {
            'id': 3,
            'code': 'BIRYANI50',
            'title': 'Biryani Deal',
            'description': 'Get 2 biryanis for Rs. 600',
            'discount_type': 'fixed',
            'value': 100,
            'min_order': 600,
            'valid_until': '2025-12-25'
        }
    ]
    
    # Initialize carts
    for user_id in [1, 2, 3, 4]:
        cart[user_id] = []
    
    print(f"✅ Initialized: {len(users_db)} users, {len(menu_items)} menu items")

# ========== HELPER FUNCTIONS ==========
def check_session(session_id):
    if not session_id or session_id not in sessions:
        return None
    return sessions[session_id]

def get_user_by_id(user_id):
    for user in users_db.values():
        if user['id'] == user_id:
            return user
    return None

def generate_order_number():
    return f"ORD-{datetime.now().strftime('%Y%m%d%H%M%S')}-{random.randint(100, 999)}"

# ========== INITIALIZE ==========
init_data()

# ========== ROUTES ==========

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status': 'online', 'message': 'CampusHub API is running!'})

# ===== AUTHENTICATION =====
@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    user = users_db.get(username)
    if not user:
        return jsonify({'error': 'Invalid credentials'}), 401
    
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    if user['password_hash'] != hashed_password:
        return jsonify({'error': 'Invalid credentials'}), 401
    
    # Create session
    session_id = str(uuid.uuid4())
    sessions[session_id] = {
        'user_id': user['id'],
        'username': user['username'],
        'role': user['role'],
        'login_time': datetime.now().isoformat()
    }
    
    return jsonify({
        'message': 'Login successful',
        'session_id': session_id,
        'user': {
            'id': user['id'],
            'username': user['username'],
            'email': user['email'],
            'role': user['role'],
            'balance': user['balance'],
            'profile_pic': user.get('profile_pic', '👤'),
            'phone': user.get('phone', ''),
            'address': user.get('address', '')
        }
    }), 200

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session_id = request.headers.get('Authorization')
    if session_id in sessions:
        del sessions[session_id]
    return jsonify({'message': 'Logged out'}), 200

@app.route('/api/auth/me', methods=['GET'])
def get_current_user():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user = get_user_by_id(user_info['user_id'])
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    return jsonify({
        'id': user['id'],
        'username': user['username'],
        'email': user['email'],
        'role': user['role'],
        'balance': user['balance'],
        'profile_pic': user.get('profile_pic', '👤'),
        'phone': user.get('phone', ''),
        'address': user.get('address', '')
    }), 200

# ===== MENU =====
@app.route('/api/menu', methods=['GET'])
def get_menu():
    category = request.args.get('category', '')
    
    if category:
        filtered = [item for item in menu_items if item['category'] == category]
    else:
        filtered = menu_items
    
    return jsonify(filtered), 200

@app.route('/api/menu/categories', methods=['GET'])
def get_categories():
    categories = list(set(item['category'] for item in menu_items))
    return jsonify(categories), 200

# ===== CART =====
@app.route('/api/cart', methods=['GET'])
def get_cart():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_id = user_info['user_id']
    user_cart = cart.get(user_id, [])
    
    # Calculate total
    total = sum(item['price'] * item['quantity'] for item in user_cart)
    
    return jsonify({
        'items': user_cart,
        'total': total,
        'count': len(user_cart)
    }), 200

@app.route('/api/cart/add', methods=['POST'])
def add_to_cart():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    item_id = data.get('item_id')
    quantity = data.get('quantity', 1)
    
    # Find menu item
    menu_item = next((item for item in menu_items if item['id'] == item_id), None)
    if not menu_item:
        return jsonify({'error': 'Item not found'}), 404
    
    user_id = user_info['user_id']
    if user_id not in cart:
        cart[user_id] = []
    
    # Check if item already in cart
    for item in cart[user_id]:
        if item['id'] == item_id:
            item['quantity'] += quantity
            return jsonify({
                'message': f'{menu_item["name"]} quantity updated',
                'cart_count': len(cart[user_id])
            }), 200
    
    # Add new item
    cart_item = {
        'id': menu_item['id'],
        'name': menu_item['name'],
        'price': menu_item['price'],
        'image': menu_item['image'],
        'quantity': quantity
    }
    cart[user_id].append(cart_item)
    
    return jsonify({
        'message': f'{menu_item["name"]} added to cart',
        'cart_count': len(cart[user_id])
    }), 200

@app.route('/api/cart/update', methods=['POST'])
def update_cart_item():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    item_id = data.get('item_id')
    quantity = data.get('quantity')
    
    if quantity is None:
        return jsonify({'error': 'Quantity required'}), 400
    
    user_id = user_info['user_id']
    user_cart = cart.get(user_id, [])
    
    # Find and update item
    for item in user_cart:
        if item['id'] == item_id:
            if quantity <= 0:
                # Remove item
                cart[user_id] = [i for i in user_cart if i['id'] != item_id]
                return jsonify({'message': 'Item removed from cart'}), 200
            else:
                item['quantity'] = quantity
                return jsonify({'message': 'Cart updated'}), 200
    
    return jsonify({'error': 'Item not found in cart'}), 404

@app.route('/api/cart/remove/<int:item_id>', methods=['DELETE'])
def remove_from_cart(item_id):
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_id = user_info['user_id']
    user_cart = cart.get(user_id, [])
    
    # Remove item
    cart[user_id] = [item for item in user_cart if item['id'] != item_id]
    
    return jsonify({'message': 'Item removed from cart'}), 200

@app.route('/api/cart/clear', methods=['POST'])
def clear_cart():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_id = user_info['user_id']
    cart[user_id] = []
    
    return jsonify({'message': 'Cart cleared'}), 200

# ===== ORDERS =====
@app.route('/api/orders', methods=['GET'])
def get_user_orders():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_orders = [order for order in orders if order['user_id'] == user_info['user_id']]
    return jsonify(user_orders), 200

@app.route('/api/orders/create', methods=['POST'])
def create_order():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    delivery_option = data.get('delivery_option', 'pickup')
    delivery_address = data.get('delivery_address', '')
    offer_code = data.get('offer_code', '')
    
    user_id = user_info['user_id']
    user_cart = cart.get(user_id, [])
    
    if not user_cart:
        return jsonify({'error': 'Cart is empty'}), 400
    
    # Calculate total
    subtotal = sum(item['price'] * item['quantity'] for item in user_cart)
    
    # Apply offer if valid
    discount = 0
    if offer_code:
        offer = next((o for o in offers if o['code'] == offer_code), None)
        if offer and subtotal >= offer['min_order']:
            if offer['discount_type'] == 'percentage':
                discount = subtotal * (offer['value'] / 100)
            else:
                discount = offer['value']
    
    tax = subtotal * 0.16  # 16% tax
    delivery_charge = 50.00 if delivery_option == 'delivery' else 0
    total = subtotal + tax + delivery_charge - discount
    
    # Check user balance
    user = get_user_by_id(user_id)
    if user['balance'] < total:
        return jsonify({'error': 'Insufficient balance'}), 400
    
    # Deduct balance
    user['balance'] -= total
    
    # Create order
    order_id = len(orders) + 1
    order_number = generate_order_number()
    
    order = {
        'id': order_id,
        'order_number': order_number,
        'user_id': user_id,
        'username': user_info['username'],
        'items': user_cart.copy(),
        'subtotal': subtotal,
        'tax': tax,
        'delivery_charge': delivery_charge,
        'discount': discount,
        'total': total,
        'status': 'pending',
        'delivery_option': delivery_option,
        'delivery_address': delivery_address if delivery_option == 'delivery' else 'Self Pickup',
        'current_status': 'Order Received',
        'progress': 0,
        'estimated_time': (datetime.now() + timedelta(minutes=30)).isoformat(),
        'created_at': datetime.now().isoformat(),
        'updates': [{
            'status': 'order_placed',
            'message': 'Order received by cafeteria',
            'time': datetime.now().isoformat()
        }]
    }
    
    orders.append(order)
    
    # Clear user cart
    cart[user_id] = []
    
    return jsonify({
        'message': 'Order placed successfully!',
        'order_number': order_number,
        'order_id': order_id,
        'total': total,
        'estimated_time': order['estimated_time']
    }), 201

@app.route('/api/orders/<int:order_id>/track', methods=['GET'])
def track_order(order_id):
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info:
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Find order
    order = next((o for o in orders if o['id'] == order_id), None)
    if not order:
        return jsonify({'error': 'Order not found'}), 404
    
    # Check permissions
    if order['user_id'] != user_info['user_id'] and user_info['role'] not in ['admin', 'kitchen_staff']:
        return jsonify({'error': 'Access denied'}), 403
    
    return jsonify(order), 200

@app.route('/api/orders/<int:order_id>/update-status', methods=['POST'])
def update_order_status(order_id):
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info or user_info['role'] not in ['admin', 'kitchen_staff']:
        return jsonify({'error': 'Permission denied'}), 403
    
    data = request.get_json()
    status = data.get('status')
    message = data.get('message', '')
    
    # Find order
    order = next((o for o in orders if o['id'] == order_id), None)
    if not order:
        return jsonify({'error': 'Order not found'}), 404
    
    # Update status
    order['status'] = status
    
    # Map status to progress
    status_progress = {
        'pending': 0,
        'confirmed': 25,
        'preparing': 50,
        'ready': 75,
        'delivered': 100,
        'picked_up': 100
    }
    
    if status in status_progress:
        order['progress'] = status_progress[status]
        order['current_status'] = status.replace('_', ' ').title()
    
    # Add update to history
    order['updates'].append({
        'status': status,
        'message': message or f'Order status updated to {status}',
        'time': datetime.now().isoformat(),
        'updated_by': user_info['username']
    })
    
    return jsonify({
        'message': f'Order status updated to {status}',
        'order': order
    }), 200

# ===== OFFERS =====
@app.route('/api/offers', methods=['GET'])
def get_offers():
    return jsonify(offers), 200

@app.route('/api/offers/validate', methods=['POST'])
def validate_offer():
    data = request.get_json()
    code = data.get('code')
    subtotal = data.get('subtotal', 0)
    
    offer = next((o for o in offers if o['code'] == code), None)
    
    if not offer:
        return jsonify({'valid': False, 'message': 'Invalid offer code'}), 200
    
    if subtotal < offer['min_order']:
        return jsonify({
            'valid': False,
            'message': f'Minimum order of Rs. {offer["min_order"]} required'
        }), 200
    
    # Calculate discount
    if offer['discount_type'] == 'percentage':
        discount = subtotal * (offer['value'] / 100)
    else:
        discount = offer['value']
    
    return jsonify({
        'valid': True,
        'discount': discount,
        'offer': offer
    }), 200

# ===== ADMIN =====
@app.route('/api/admin/orders', methods=['GET'])
def get_all_orders():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info or user_info['role'] != 'admin':
        return jsonify({'error': 'Admin access required'}), 403
    
    return jsonify(orders), 200

@app.route('/api/admin/stats', methods=['GET'])
def get_admin_stats():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info or user_info['role'] != 'admin':
        return jsonify({'error': 'Admin access required'}), 403
    
    # Calculate stats
    total_revenue = sum(order['total'] for order in orders)
    today = datetime.now().date()
    today_orders = [o for o in orders if datetime.fromisoformat(o['created_at']).date() == today]
    
    stats = {
        'total_orders': len(orders),
        'total_revenue': total_revenue,
        'today_orders': len(today_orders),
        'today_revenue': sum(o['total'] for o in today_orders),
        'active_users': len(sessions),
        'pending_orders': len([o for o in orders if o['status'] == 'pending'])
    }
    
    return jsonify(stats), 200

# ===== KITCHEN STAFF =====
@app.route('/api/kitchen/orders', methods=['GET'])
def get_kitchen_orders():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info or user_info['role'] not in ['kitchen_staff', 'admin']:
        return jsonify({'error': 'Kitchen staff access required'}), 403
    
    # Get pending orders
    kitchen_orders = [o for o in orders if o['status'] in ['pending', 'confirmed', 'preparing']]
    
    return jsonify(kitchen_orders), 200

# ===== USER MANAGEMENT =====
@app.route('/api/user/balance/add', methods=['POST'])
def add_balance():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    amount = data.get('amount', 0)
    
    if amount <= 0:
        return jsonify({'error': 'Invalid amount'}), 400
    
    user = get_user_by_id(user_info['user_id'])
    user['balance'] += amount
    
    return jsonify({
        'message': f'Rs. {amount} added to your balance',
        'new_balance': user['balance']
    }), 200

@app.route('/api/user/update-profile', methods=['PUT'])
def update_profile():
    session_id = request.headers.get('Authorization')
    user_info = check_session(session_id)
    
    if not user_info:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    user = get_user_by_id(user_info['user_id'])
    
    # Update allowed fields
    allowed_fields = ['phone', 'address']
    for field in allowed_fields:
        if field in data:
            user[field] = data[field]
    
    return jsonify({
        'message': 'Profile updated successfully',
        'user': user
    }), 200

# ===== ERROR HANDLERS =====
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    print("\n" + "="*70)
    print("🎉 CAMPUSHUB PREMIUM CAFETERIA - BACKEND SERVER")
    print("="*70)
    print("📡 Server: http://localhost:5000")
    print("\n🔑 TEST CREDENTIALS:")
    print("   👑 Admin: username=admin, password=admin123")
    print("   👨‍🎓 Student: username=student1, password=password123")
    print("   👨‍🏫 Teacher: username=teacher1, password=teacher123")
    print("   👨‍🍳 Kitchen Staff: username=kitchen1, password=kitchen123")
    print("\n✅ ALL FEATURES WORKING")
    print("="*70)
    
    app.run(debug=True, port=5000)