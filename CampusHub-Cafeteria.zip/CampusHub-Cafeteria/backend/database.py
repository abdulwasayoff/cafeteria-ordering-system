import sqlite3
import hashlib
import json
import os
from datetime import datetime
from typing import Optional, List, Dict, Any

class Database:
    def __init__(self, db_name: str = 'campus_hub.db'):
        """
        Initialize database connection with improved error handling
        """
        self.db_name = db_name
        try:
            self.conn = sqlite3.connect(db_name, check_same_thread=False)
            self.conn.row_factory = sqlite3.Row
            self.create_tables()
            self.add_sample_data()
        except sqlite3.Error as e:
            print(f"❌ Database connection error: {e}")
            raise
    
    def create_tables(self):
        """
        Create all necessary tables with proper constraints
        """
        cursor = self.conn.cursor()
        
        try:
            # Users table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    role TEXT DEFAULT 'student' CHECK(role IN ('admin', 'student', 'teacher', 'kitchen_staff')),
                    balance REAL DEFAULT 0.00 CHECK(balance >= 0),
                    profile_pic TEXT DEFAULT '👤',
                    phone TEXT,
                    address TEXT,
                    security_question TEXT,
                    security_answer TEXT,
                    is_active BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Menu items
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS menu_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    description TEXT,
                    category TEXT NOT NULL,
                    price REAL NOT NULL CHECK(price > 0),
                    image_url TEXT,
                    rating REAL DEFAULT 4.0 CHECK(rating >= 0 AND rating <= 5),
                    prep_time INTEGER DEFAULT 15,  -- in minutes
                    calories INTEGER,
                    tags TEXT,  -- JSON array of tags
                    customizations TEXT,  -- JSON array of customizations
                    is_available BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Orders table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    order_number TEXT UNIQUE NOT NULL,
                    user_id INTEGER NOT NULL,
                    items TEXT NOT NULL,  -- JSON string of items
                    subtotal REAL NOT NULL CHECK(subtotal >= 0),
                    tax REAL DEFAULT 0 CHECK(tax >= 0),
                    delivery_charge REAL DEFAULT 0 CHECK(delivery_charge >= 0),
                    discount REAL DEFAULT 0 CHECK(discount >= 0),
                    total_amount REAL NOT NULL CHECK(total_amount >= 0),
                    status TEXT DEFAULT 'pending' 
                        CHECK(status IN ('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'picked_up', 'cancelled')),
                    delivery_option TEXT DEFAULT 'pickup',
                    delivery_address TEXT,
                    current_status TEXT DEFAULT 'Order Received',
                    progress INTEGER DEFAULT 0 CHECK(progress >= 0 AND progress <= 100),
                    estimated_time TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                )
            ''')
            
            # Order updates table (for tracking order history)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS order_updates (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    order_id INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    message TEXT,
                    updated_by TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
                )
            ''')
            
            # Cart table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS cart (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    item_id INTEGER NOT NULL,
                    quantity INTEGER DEFAULT 1 CHECK(quantity > 0),
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, item_id),
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (item_id) REFERENCES menu_items(id) ON DELETE CASCADE
                )
            ''')
            
            # Offers table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS offers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    code TEXT UNIQUE NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT,
                    discount_type TEXT CHECK(discount_type IN ('percentage', 'fixed')),
                    value REAL NOT NULL CHECK(value >= 0),
                    min_order REAL DEFAULT 0,
                    valid_until DATE,
                    is_active BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Transactions table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    type TEXT CHECK(type IN ('deposit', 'withdrawal', 'purchase', 'refund')),
                    amount REAL NOT NULL,
                    description TEXT,
                    order_id INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
                )
            ''')
            
            # Create indexes for better performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_cart_user_id ON cart(user_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_menu_category ON menu_items(category)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_offers_code ON offers(code)')
            
            self.conn.commit()
            print("✅ Database tables created successfully!")
            
        except sqlite3.Error as e:
            print(f"❌ Error creating tables: {e}")
            self.conn.rollback()
            raise
    
    def add_sample_data(self):
        """
        Add initial sample data to the database
        """
        cursor = self.conn.cursor()
        
        try:
            # Check if sample data already exists
            cursor.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'")
            admin_exists = cursor.fetchone()[0] > 0
            
            if not admin_exists:
                # Add users with more detailed information
                users = [
                    ('admin', 'admin@campushub.com', 'admin123', 'admin', 1000.00, '👑', 
                     '+92 300 1234567', 'Admin Block, PAF-IAST', 'What is your pet name?', 'Max'),
                    ('student1', 'student1@campushub.com', 'password123', 'student', 500.00, '👨‍🎓',
                     '+92 300 7654321', 'Hostel Block A, Room 101', 'What is your favorite color?', 'Blue'),
                    ('teacher1', 'teacher@campushub.com', 'teacher123', 'teacher', 800.00, '👨‍🏫',
                     '+92 300 1122334', 'Faculty Quarters, Block C', 'What is your birth city?', 'Islamabad'),
                    ('kitchen1', 'kitchen@campushub.com', 'kitchen123', 'kitchen_staff', 0.00, '👨‍🍳',
                     '+92 300 4455667', 'Kitchen Area, Cafeteria', 'What is your favorite dish?', 'Biryani')
                ]
                
                for username, email, password, role, balance, profile_pic, phone, address, sec_q, sec_a in users:
                    hashed_pw = hashlib.sha256(password.encode()).hexdigest()
                    cursor.execute('''
                        INSERT INTO users (username, email, password_hash, role, balance, 
                                          profile_pic, phone, address, security_question, security_answer)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (username, email, hashed_pw, role, balance, profile_pic, phone, address, sec_q, sec_a))
                
                # Add comprehensive menu items
                menu_items = [
                    # Breakfast items
                    ('Paratha with Omelette', 'Freshly made paratha served with fluffy omelette', 'Breakfast', 
                     180.00, 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=400&h=300&fit=crop',
                     4.8, 10, 450, json.dumps(['Vegetarian', 'Popular']), json.dumps(['Extra Omelette', 'Butter', 'Pickle'])),
                    
                    ('Halwa Puri', 'Traditional breakfast with semolina halwa and puri', 'Breakfast',
                     220.00, 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=400&h=300&fit=crop',
                     4.9, 15, 550, json.dumps(['Vegetarian', 'Special']), json.dumps(['Extra Halwa', 'Chickpeas'])),
                    
                    ('Lahori Channay', 'Spicy chickpeas with traditional Lahori spices', 'Breakfast',
                     150.00, 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop',
                     4.7, 12, 320, json.dumps(['Vegetarian', 'Spicy']), json.dumps(['Extra Spicy', 'With Puri'])),
                    
                    # Desi Food
                    ('Chicken Karahi', 'Spicy chicken cooked in traditional karahi', 'Desi Food',
                     450.00, 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&h=300&fit=crop',
                     4.9, 25, 650, json.dumps(['Non-Veg', 'Spicy', 'Special']), json.dumps(['Extra Spicy', 'With Naan', 'Boneless'])),
                    
                    ('Biryani', 'Fragrant rice with tender chicken and spices', 'Desi Food',
                     350.00, 'https://images.unsplash.com/photo-1563379091339-03246963d9d6?w=400&h=300&fit=crop',
                     4.8, 30, 720, json.dumps(['Non-Veg', 'Rice', 'Popular']), json.dumps(['Extra Raita', 'With Salad', 'Spicy'])),
                    
                    # Fast Food
                    ('Zinger Burger', 'Crispy chicken burger with special sauce', 'Fast Food',
                     320.00, 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop',
                     4.6, 12, 580, json.dumps(['Non-Veg', 'Popular']), json.dumps(['Extra Cheese', 'Extra Sauce', 'No Mayo'])),
                    
                    ('Cheese Pizza', '12-inch pizza with mozzarella cheese', 'Fast Food',
                     650.00, 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop',
                     4.7, 20, 850, json.dumps(['Vegetarian', 'Italian']), json.dumps(['Extra Cheese', 'Extra Toppings', 'Thin Crust'])),
                    
                    # Beverages
                    ('Fresh Lime', 'Fresh lime with mint and soda', 'Beverages',
                     120.00, 'https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?w=400&h=300&fit=crop',
                     4.5, 5, 90, json.dumps(['Cold', 'Refreshing']), json.dumps(['Sweet', 'Sour', 'With Soda'])),
                    
                    ('Cold Coffee', 'Iced coffee with cream and chocolate', 'Beverages',
                     180.00, 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=400&h=300&fit=crop',
                     4.6, 7, 150, json.dumps(['Cold', 'Coffee']), json.dumps(['Extra Cream', 'Less Sugar', 'Chocolate']))
                ]
                
                cursor.executemany('''
                    INSERT INTO menu_items (name, description, category, price, image_url, 
                                           rating, prep_time, calories, tags, customizations)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', menu_items)
                
                # Add offers
                offers = [
                    ('STUDENT20', 'Student Special', '20% off for all students', 'percentage', 20, 300, '2025-12-31'),
                    ('FIRSTORDER', 'First Order', '15% off on first order', 'percentage', 15, 500, '2025-12-31'),
                    ('BIRYANI50', 'Biryani Deal', 'Get 2 biryanis for Rs. 600', 'fixed', 100, 600, '2025-12-25')
                ]
                
                cursor.executemany('''
                    INSERT INTO offers (code, title, description, discount_type, value, min_order, valid_until)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', offers)
                
                self.conn.commit()
                print("✅ Sample data added successfully!")
            else:
                print("ℹ️ Sample data already exists, skipping...")
                
        except sqlite3.Error as e:
            print(f"❌ Error adding sample data: {e}")
            self.conn.rollback()
    
    # ========== USER METHODS ==========
    
    def get_user(self, username: str) -> Optional[sqlite3.Row]:
        """Get user by username"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ? AND is_active = 1", (username,))
        return cursor.fetchone()
    
    def get_user_by_id(self, user_id: int) -> Optional[sqlite3.Row]:
        """Get user by ID"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM users WHERE id = ? AND is_active = 1", (user_id,))
        return cursor.fetchone()
    
    def verify_user(self, username: str, password: str) -> Optional[sqlite3.Row]:
        """Verify user credentials"""
        user = self.get_user(username)
        if user:
            hashed_input = hashlib.sha256(password.encode()).hexdigest()
            return user if user['password_hash'] == hashed_input else None
        return None
    
    def create_user(self, username: str, email: str, password: str, role: str = 'student',
                   security_question: str = None, security_answer: str = None) -> bool:
        """Create a new user"""
        hashed_pw = hashlib.sha256(password.encode()).hexdigest()
        cursor = self.conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO users (username, email, password_hash, role, security_question, security_answer)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (username, email, hashed_pw, role, security_question, security_answer))
            self.conn.commit()
            return True
        except sqlite3.IntegrityError as e:
            print(f"❌ User creation error: {e}")
            return False
    
    def update_user_balance(self, user_id: int, amount: float) -> bool:
        """Update user balance (positive for deposit, negative for withdrawal)"""
        cursor = self.conn.cursor()
        try:
            cursor.execute('''
                UPDATE users 
                SET balance = balance + ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND (balance + ? >= 0 OR ? > 0)
            ''', (amount, user_id, amount, amount))
            
            if cursor.rowcount > 0:
                # Record transaction
                transaction_type = 'deposit' if amount > 0 else 'withdrawal'
                cursor.execute('''
                    INSERT INTO transactions (user_id, type, amount, description)
                    VALUES (?, ?, ?, ?)
                ''', (user_id, transaction_type, abs(amount), 
                     f"{transaction_type.capitalize()} of Rs. {abs(amount):.2f}"))
                
                self.conn.commit()
                return True
            return False
        except sqlite3.Error as e:
            print(f"❌ Error updating balance: {e}")
            self.conn.rollback()
            return False
    
    # ========== MENU METHODS ==========
    
    def get_menu_items(self, category: str = None) -> List[sqlite3.Row]:
        """Get all available menu items, optionally filtered by category"""
        cursor = self.conn.cursor()
        if category:
            cursor.execute("SELECT * FROM menu_items WHERE is_available = 1 AND category = ?", (category,))
        else:
            cursor.execute("SELECT * FROM menu_items WHERE is_available = 1")
        return cursor.fetchall()
    
    def get_menu_categories(self) -> List[str]:
        """Get all unique menu categories"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT DISTINCT category FROM menu_items WHERE is_available = 1")
        return [row['category'] for row in cursor.fetchall()]
    
    # ========== CART METHODS ==========
    
    def add_to_cart(self, user_id: int, item_id: int, quantity: int = 1) -> bool:
        """Add item to cart or update quantity"""
        cursor = self.conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO cart (user_id, item_id, quantity)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id, item_id) 
                DO UPDATE SET quantity = cart.quantity + excluded.quantity
            ''', (user_id, item_id, quantity))
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            print(f"❌ Error adding to cart: {e}")
            self.conn.rollback()
            return False
    
    def get_cart(self, user_id: int) -> List[sqlite3.Row]:
        """Get user's cart items with menu item details"""
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT c.*, m.name, m.price, m.image_url, m.description
            FROM cart c 
            JOIN menu_items m ON c.item_id = m.id 
            WHERE c.user_id = ? AND m.is_available = 1
        ''', (user_id,))
        return cursor.fetchall()
    
    def update_cart_item(self, user_id: int, item_id: int, quantity: int) -> bool:
        """Update cart item quantity"""
        cursor = self.conn.cursor()
        try:
            if quantity <= 0:
                # Remove item if quantity is 0 or negative
                cursor.execute("DELETE FROM cart WHERE user_id = ? AND item_id = ?", (user_id, item_id))
            else:
                cursor.execute('''
                    UPDATE cart SET quantity = ? 
                    WHERE user_id = ? AND item_id = ?
                ''', (quantity, user_id, item_id))
            
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            print(f"❌ Error updating cart: {e}")
            self.conn.rollback()
            return False
    
    def remove_from_cart(self, user_id: int, item_id: int) -> bool:
        """Remove item from cart"""
        cursor = self.conn.cursor()
        try:
            cursor.execute("DELETE FROM cart WHERE user_id = ? AND item_id = ?", (user_id, item_id))
            self.conn.commit()
            return cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"❌ Error removing from cart: {e}")
            self.conn.rollback()
            return False
    
    def clear_cart(self, user_id: int) -> bool:
        """Clear user's entire cart"""
        cursor = self.conn.cursor()
        try:
            cursor.execute("DELETE FROM cart WHERE user_id = ?", (user_id,))
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            print(f"❌ Error clearing cart: {e}")
            self.conn.rollback()
            return False
    
    # ========== ORDER METHODS ==========
    
    def create_order(self, user_id: int, items: List[Dict], subtotal: float, 
                    tax: float, delivery_charge: float, discount: float,
                    total_amount: float, delivery_option: str = 'pickup',
                    delivery_address: str = '') -> Optional[str]:
        """Create a new order"""
        cursor = self.conn.cursor()
        
        try:
            # Generate order number
            order_number = f"ORD-{datetime.now().strftime('%Y%m%d')}-{user_id:04d}-{os.urandom(2).hex().upper()}"
            
            # Check user balance
            cursor.execute("SELECT balance FROM users WHERE id = ?", (user_id,))
            user_balance = cursor.fetchone()['balance']
            
            if user_balance < total_amount:
                return None  # Insufficient balance
            
            # Deduct from balance
            cursor.execute('''
                UPDATE users SET balance = balance - ? 
                WHERE id = ?
            ''', (total_amount, user_id))
            
            # Create order
            cursor.execute('''
                INSERT INTO orders (order_number, user_id, items, subtotal, tax, 
                                  delivery_charge, discount, total_amount, 
                                  delivery_option, delivery_address, estimated_time)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', '+30 minutes'))
            ''', (order_number, user_id, json.dumps(items), subtotal, tax, 
                 delivery_charge, discount, total_amount, delivery_option, delivery_address))
            
            order_id = cursor.lastrowid
            
            # Record transaction
            cursor.execute('''
                INSERT INTO transactions (user_id, type, amount, order_id, description)
                VALUES (?, 'purchase', ?, ?, ?)
            ''', (user_id, total_amount, order_id, f"Order #{order_number}"))
            
            # Add initial order update
            cursor.execute('''
                INSERT INTO order_updates (order_id, status, message)
                VALUES (?, 'order_placed', 'Order received by cafeteria')
            ''', (order_id,))
            
            # Clear cart
            self.clear_cart(user_id)
            
            self.conn.commit()
            return order_number
            
        except sqlite3.Error as e:
            print(f"❌ Error creating order: {e}")
            self.conn.rollback()
            return None
    
    def get_orders(self, user_id: int = None) -> List[sqlite3.Row]:
        """Get orders, optionally filtered by user_id"""
        cursor = self.conn.cursor()
        if user_id:
            cursor.execute('''
                SELECT o.*, u.username, u.profile_pic
                FROM orders o
                JOIN users u ON o.user_id = u.id
                WHERE o.user_id = ?
                ORDER BY o.created_at DESC
            ''', (user_id,))
        else:
            cursor.execute('''
                SELECT o.*, u.username, u.profile_pic
                FROM orders o
                JOIN users u ON o.user_id = u.id
                ORDER BY o.created_at DESC
            ''')
        return cursor.fetchall()
    
    def get_order(self, order_id: int) -> Optional[sqlite3.Row]:
        """Get order by ID"""
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT o.*, u.username, u.email, u.phone, u.address
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.id = ?
        ''', (order_id,))
        return cursor.fetchone()
    
    def update_order_status(self, order_id: int, status: str, message: str = '', updated_by: str = 'System') -> bool:
        """Update order status and add to history"""
        cursor = self.conn.cursor()
        
        try:
            # Update order
            cursor.execute('''
                UPDATE orders 
                SET status = ?, current_status = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (status, message or f"Order status updated to {status}", order_id))
            
            # Add to order updates
            cursor.execute('''
                INSERT INTO order_updates (order_id, status, message, updated_by)
                VALUES (?, ?, ?, ?)
            ''', (order_id, status, message or f"Order status updated to {status}", updated_by))
            
            self.conn.commit()
            return True
            
        except sqlite3.Error as e:
            print(f"❌ Error updating order status: {e}")
            self.conn.rollback()
            return False
    
    def get_order_updates(self, order_id: int) -> List[sqlite3.Row]:
        """Get all updates for an order"""
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT * FROM order_updates 
            WHERE order_id = ? 
            ORDER BY created_at ASC
        ''', (order_id,))
        return cursor.fetchall()
    
    # ========== OFFER METHODS ==========
    
    def get_offers(self) -> List[sqlite3.Row]:
        """Get all active offers"""
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT * FROM offers 
            WHERE is_active = 1 AND (valid_until IS NULL OR valid_until >= date('now'))
        ''')
        return cursor.fetchall()
    
    def validate_offer(self, code: str, subtotal: float) -> Optional[Dict]:
        """Validate an offer code"""
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT * FROM offers 
            WHERE code = ? AND is_active = 1 
            AND (valid_until IS NULL OR valid_until >= date('now'))
        ''', (code,))
        
        offer = cursor.fetchone()
        if not offer:
            return None
        
        if subtotal < offer['min_order']:
            return None
        
        # Calculate discount
        if offer['discount_type'] == 'percentage':
            discount = subtotal * (offer['value'] / 100)
        else:
            discount = offer['value']
        
        return {
            'id': offer['id'],
            'code': offer['code'],
            'title': offer['title'],
            'discount': discount,
            'discount_type': offer['discount_type'],
            'value': offer['value']
        }
    
    # ========== STATISTICS METHODS ==========
    
    def get_stats(self) -> Dict[str, Any]:
        """Get system statistics"""
        cursor = self.conn.cursor()
        
        stats = {}
        
        # Basic counts
        cursor.execute("SELECT COUNT(*) FROM users WHERE is_active = 1")
        stats['total_users'] = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM menu_items WHERE is_available = 1")
        stats['total_menu_items'] = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM orders")
        stats['total_orders'] = cursor.fetchone()[0]
        
        # Revenue
        cursor.execute("SELECT SUM(total_amount) FROM orders")
        stats['total_revenue'] = cursor.fetchone()[0] or 0
        
        # Today's stats
        cursor.execute("SELECT COUNT(*), SUM(total_amount) FROM orders WHERE date(created_at) = date('now')")
        today_result = cursor.fetchone()
        stats['today_orders'] = today_result[0] or 0
        stats['today_revenue'] = today_result[1] or 0
        
        # Order status counts
        cursor.execute('''
            SELECT status, COUNT(*) as count 
            FROM orders 
            GROUP BY status
        ''')
        stats['order_statuses'] = {row['status']: row['count'] for row in cursor.fetchall()}
        
        # Popular categories
        cursor.execute('''
            SELECT m.category, COUNT(*) as count
            FROM orders o, json_each(o.items) j
            JOIN menu_items m ON json_extract(j.value, '$.id') = m.id
            GROUP BY m.category
            ORDER BY count DESC
            LIMIT 5
        ''')
        stats['popular_categories'] = cursor.fetchall()
        
        return stats
    
    # ========== UTILITY METHODS ==========
    
    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# Create database instance
if __name__ == "__main__":
    db = Database()
    
    # Test the database
    print("\n🧪 Testing database...")
    
    # Test getting users
    admin = db.get_user('admin')
    if admin:
        print(f"✅ Found admin: {admin['username']} (Role: {admin['role']})")
    
    # Test getting menu
    menu_items = db.get_menu_items()
    print(f"✅ Found {len(menu_items)} menu items")
    
    # Test categories
    categories = db.get_menu_categories()
    print(f"✅ Menu categories: {categories}")
    
    # Test offers
    offers = db.get_offers()
    print(f"✅ Found {len(offers)} active offers")
    
    # Test stats
    stats = db.get_stats()
    print(f"✅ System stats: {stats['total_users']} users, {stats['total_orders']} orders")
    
    print("\n🎉 Database setup complete and working!")