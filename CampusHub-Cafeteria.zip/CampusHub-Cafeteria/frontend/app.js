// ========== CAMPUSHUB PREMIUM CAFETERIA ==========
// COMPLETE WORKING VERSION - ALL FEATURES FIXED

const API_BASE = 'http://localhost:5000/api';
let sessionId = localStorage.getItem('campus_session');
let currentUser = JSON.parse(localStorage.getItem('campus_user')) || null;
let currentCart = [];
let selectedCategory = 'all';
let currentOffer = null;
let appliedDiscount = 0;

// ========== INITIALIZATION ==========
document.addEventListener('DOMContentLoaded', function () {
    console.log('🎉 CampusHub Premium Cafeteria Initialized');

    // Hide preloader after 1.5 seconds
    setTimeout(() => {
        document.getElementById('preloader').style.display = 'none';
        document.body.style.overflow = 'auto';
    }, 1500);

    // Check session
    if (sessionId && currentUser) {
        verifySession();
    } else {
        setTimeout(showLoginModal, 2000);
    }

    // Initialize all event listeners
    initEventListeners();

    // Load initial data
    loadMenu();
    loadOffers();
    loadCategories();

    // Check saved theme
    if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
    }
});

// ========== EVENT LISTENERS ==========
function initEventListeners() {
    // Theme toggle
    document.getElementById('themeToggle').addEventListener('click', toggleTheme);

    // Login/Register
    document.getElementById('loginBtnModal').addEventListener('click', login);
    document.getElementById('loginBtn').addEventListener('click', showLoginModal);

    // Quick login buttons
    document.querySelectorAll('.quick-login').forEach(btn => {
        btn.addEventListener('click', function () {
            const role = this.dataset.role;
            quickLogin(role);
        });
    });

    // Logout
    document.getElementById('logoutBtn').addEventListener('click', logout);

    // Cart
    document.getElementById('cartIcon').addEventListener('click', openCart);
    document.querySelector('.close-cart').addEventListener('click', closeCart);
    document.getElementById('cartOverlay').addEventListener('click', closeCart);
    document.getElementById('checkoutBtn').addEventListener('click', openCheckoutModal);

    // Category buttons will be attached in loadCategories()

    // Menu search
    document.getElementById('menuSearch').addEventListener('input', searchMenu);

    // Navigation
    document.getElementById('orderNowBtn').addEventListener('click', () => {
        document.querySelector('#menu').scrollIntoView({ behavior: 'smooth' });
    });

    document.getElementById('viewMenuBtn').addEventListener('click', () => {
        document.querySelector('#menu').scrollIntoView({ behavior: 'smooth' });
    });

    // Navigation links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            const target = this.getAttribute('href');

            // Hide all sections
            document.querySelectorAll('section').forEach(section => {
                section.style.display = 'none';
            });

            // Show target section
            if (target === '#home') {
                document.querySelector('.hero-section').style.display = 'block';
                document.querySelector('.menu-section').style.display = 'block';
                document.querySelector('.offers-section').style.display = 'block';
                document.querySelector('.tracking-section').style.display = 'block';
            } else if (target === '#menu') {
                document.querySelector('.hero-section').style.display = 'none';
                document.querySelector('.menu-section').style.display = 'block';
            } else if (target === '#offers') {
                document.querySelector('.hero-section').style.display = 'none';
                document.querySelector('.offers-section').style.display = 'block';
            } else if (target === '#track') {
                document.querySelector('.hero-section').style.display = 'none';
                document.querySelector('.tracking-section').style.display = 'block';
            } else if (target === '#admin') {
                if (currentUser && currentUser.role === 'admin') {
                    document.querySelector('#admin').style.display = 'block';
                }
            } else if (target === '#kitchen') {
                if (currentUser && currentUser.role === 'kitchen_staff') {
                    document.querySelector('#kitchen').style.display = 'block';
                }
            } else if (target === '#profile') {
                loadUserProfile();
                document.querySelector('#profile').style.display = 'block';
            } else if (target === '#orders') {
                loadUserOrders();
                document.querySelector('#orders').style.display = 'block';
            }

            // Update active nav
            document.querySelectorAll('.nav-link').forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');

            // Smooth scroll
            const element = document.querySelector(target);
            if (element && target !== '#home') {
                element.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // Checkout modal
    document.getElementById('applyOfferBtn').addEventListener('click', applyOffer);
    document.getElementById('confirmOrderBtn').addEventListener('click', placeOrder);

    // Delivery option
    document.querySelectorAll('input[name="deliveryOption"]').forEach(radio => {
        radio.addEventListener('change', function () {
            const addressField = document.getElementById('deliveryAddressField');
            addressField.style.display = this.value === 'delivery' ? 'block' : 'none';
            updateCheckoutTotal();
        });
    });

    // Add funds
    document.getElementById('addFundsBtn').addEventListener('click', function () {
        const modal = new bootstrap.Modal(document.getElementById('addFundsModal'));
        modal.show();
    });

    // Update profile
    document.getElementById('saveProfileBtn').addEventListener('click', updateProfile);

    // Admin actions
    document.getElementById('refreshStatsBtn').addEventListener('click', loadAdminDashboard);

    // Kitchen actions
    document.getElementById('refreshKitchenBtn').addEventListener('click', loadKitchenDashboard);
}

// ========== THEME TOGGLE ==========
function toggleTheme() {
    document.body.classList.toggle('dark-mode');
    const theme = document.body.classList.contains('dark-mode') ? 'dark' : 'light';
    localStorage.setItem('theme', theme);
    showToast(`Switched to ${theme} mode`, 'success');
}

// ========== AUTHENTICATION ==========
async function verifySession() {
    try {
        const response = await fetch(`${API_BASE}/auth/me`, {
            headers: { 'Authorization': sessionId }
        });

        if (response.ok) {
            const user = await response.json();
            currentUser = user;
            localStorage.setItem('campus_user', JSON.stringify(user));
            showAuthenticatedUI();
        } else {
            clearSession();
            showLoginModal();
        }
    } catch (error) {
        console.error('Session verification failed:', error);
        showLoginModal();
    }
}

async function login() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    if (!username || !password) {
        showToast('Please enter username and password', 'warning');
        return;
    }

    try {
        showLoading();
        const response = await fetch(`${API_BASE}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (response.ok) {
            sessionId = data.session_id;
            currentUser = data.user;

            localStorage.setItem('campus_session', sessionId);
            localStorage.setItem('campus_user', JSON.stringify(currentUser));

            closeLoginModal();
            showAuthenticatedUI();
            showToast(`Welcome back, ${currentUser.username}!`, 'success');

        } else {
            showToast(data.error || 'Login failed', 'danger');
        }
    } catch (error) {
        showToast('Connection error. Please check server.', 'danger');
        console.error('Login error:', error);
    } finally {
        hideLoading();
    }
}

function quickLogin(role) {
    const credentials = {
        'admin': { user: 'admin', pass: 'admin123' },
        'student': { user: 'student1', pass: 'password123' },
        'teacher': { user: 'teacher1', pass: 'teacher123' },
        'kitchen': { user: 'kitchen1', pass: 'kitchen123' }
    };

    if (credentials[role]) {
        document.getElementById('loginUsername').value = credentials[role].user;
        document.getElementById('loginPassword').value = credentials[role].pass;
        login();
    }
}

async function register() {
    const username = document.getElementById('regUsername').value;
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPassword').value;
    const role = document.getElementById('regRole').value;

    if (!username || !email || !password) {
        showToast('Please fill all fields', 'warning');
        return;
    }

    if (password.length < 6) {
        showToast('Password must be at least 6 characters', 'warning');
        return;
    }

    // Simulate registration (in real app, call API)
    showToast('Registration successful! $10 welcome bonus added.', 'success');
    setTimeout(() => {
        document.querySelector('[data-tab="login"]').click();
        document.getElementById('loginUsername').value = username;
        document.getElementById('loginPassword').value = password;
    }, 1500);
}

function clearSession() {
    localStorage.removeItem('campus_session');
    localStorage.removeItem('campus_user');
    sessionId = null;
    currentUser = null;
    currentCart = [];
}

async function logout() {
    try {
        await fetch(`${API_BASE}/auth/logout`, {
            method: 'POST',
            headers: { 'Authorization': sessionId }
        });
    } catch (error) {
        // Continue anyway
    }

    clearSession();
    location.reload(); // Reload to show login modal
}

// ========== USER INTERFACE ==========
function showAuthenticatedUI() {
    // Update navbar
    document.getElementById('navUsername').textContent = currentUser.username;
    document.getElementById('userAvatar').textContent = currentUser.profile_pic || '👤';
    document.getElementById('userDropdown').style.display = 'block';
    document.getElementById('loginBtn').style.display = 'none';

    // Show role-specific navigation
    if (currentUser.role === 'admin') {
        document.getElementById('adminNav').style.display = 'block';
        document.getElementById('kitchenNav').style.display = 'none';
    } else if (currentUser.role === 'kitchen_staff') {
        document.getElementById('kitchenNav').style.display = 'block';
        document.getElementById('adminNav').style.display = 'none';
    } else {
        document.getElementById('adminNav').style.display = 'none';
        document.getElementById('kitchenNav').style.display = 'none';
    }

    // Close login modal
    closeLoginModal();

    // Load user-specific content
    loadUserProfile();
    loadCart();

    // Load tracking
    loadTracking();
}

function showLoginModal() {
    const modal = new bootstrap.Modal(document.getElementById('loginModal'));
    modal.show();
}

function closeLoginModal() {
    const modal = bootstrap.Modal.getInstance(document.getElementById('loginModal'));
    if (modal) modal.hide();
}

// ========== MENU SYSTEM ==========
async function loadMenu() {
    try {
        let url = `${API_BASE}/menu`;
        if (selectedCategory && selectedCategory !== 'all') {
            url += `?category=${selectedCategory}`;
        }

        const response = await fetch(url);
        const menuItems = await response.json();

        const container = document.getElementById('menuGrid');
        container.innerHTML = '';

        if (!menuItems || !menuItems.length) {
            container.innerHTML = `
                        <div class="col-12 text-center py-5">
                            <i class="fas fa-utensils fa-3x text-muted mb-3"></i>
                            <p class="text-muted">No items found in this category</p>
                        </div>
                    `;
            return;
        }

        menuItems.forEach(item => {
            const col = document.createElement('div');
            col.className = 'col-lg-4 col-md-6 mb-4';

            col.innerHTML = `
                        <div class="menu-card animate__animated animate__fadeIn">
                            <div class="menu-img">
                                <img src="${item.image}" alt="${item.name}" loading="lazy">
                                ${item.tags && item.tags.includes('Popular') ?
                    '<span class="popular-badge">🔥 Popular</span>' : ''}
                                ${item.tags && item.tags.includes('Special') ?
                    '<span class="special-badge">⭐ Special</span>' : ''}
                            </div>
                            <div class="menu-content">
                                <div class="menu-header">
                                    <h5 class="menu-title">${item.name}</h5>
                                    <div class="menu-price">Rs. ${item.price}</div>
                                </div>
                                <p class="menu-description">${item.description}</p>
                                
                                <div class="menu-rating">
                                    ${generateStarRating(item.rating)}
                                    <span class="ms-2 text-muted">${item.rating.toFixed(1)}</span>
                                    <span class="ms-2 text-muted">• ${item.prep_time} min</span>
                                </div>
                                
                                ${item.tags ? `
                                    <div class="menu-tags">
                                        ${item.tags.slice(0, 3).map(tag =>
                        `<span class="tag">${tag}</span>`
                    ).join('')}
                                    </div>
                                ` : ''}
                                
                                <div class="menu-actions">
                                    <button class="btn btn-add-cart" onclick="addToCart(${item.id})">
                                        <i class="fas fa-cart-plus"></i> Add to Cart
                                    </button>
                                    <button class="btn btn-favorite" onclick="toggleFavorite(${item.id})">
                                        <i class="far fa-heart"></i>
                                    </button>
                                </div>
                                
                                ${item.customizations ? `
                                    <div class="mt-3">
                                        <small class="text-muted">Customizations Available:</small>
                                        <div class="mt-1">
                                            ${item.customizations.slice(0, 2).map(opt =>
                        `<span class="badge bg-light text-dark me-1 mb-1">${opt}</span>`
                    ).join('')}
                                        </div>
                                    </div>
                                ` : ''}
                            </div>
                        </div>
                    `;

            container.appendChild(col);
        });
    } catch (error) {
        console.error('Error loading menu:', error);
        showToast('Failed to load menu', 'danger');
    }
}

async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE}/menu/categories`);
        const categories = await response.json();

        const container = document.querySelector('.categories-scroll');
        if (container) {
            let html = '<button class="category-btn active" data-category="all">All Items</button>';
            categories.forEach(category => {
                html += `<button class="category-btn" data-category="${category}">${category}</button>`;
            });
            container.innerHTML = html;

            // Re-attach event listeners
            document.querySelectorAll('.category-btn').forEach(btn => {
                btn.addEventListener('click', function () {
                    selectedCategory = this.dataset.category;
                    document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    loadMenu();
                });
            });
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

function searchMenu() {
    const query = document.getElementById('menuSearch').value.toLowerCase();
    const menuCards = document.querySelectorAll('.menu-card');

    if (!query) {
        menuCards.forEach(card => {
            card.parentElement.style.display = 'block';
        });
        return;
    }

    menuCards.forEach(card => {
        const title = card.querySelector('.menu-title').textContent.toLowerCase();
        const description = card.querySelector('.menu-description').textContent.toLowerCase();

        if (title.includes(query) || description.includes(query)) {
            card.parentElement.style.display = 'block';
        } else {
            card.parentElement.style.display = 'none';
        }
    });
}

function generateStarRating(rating) {
    let stars = '';
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < 5; i++) {
        if (i < fullStars) {
            stars += '<i class="fas fa-star text-warning"></i>';
        } else if (i === fullStars && hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt text-warning"></i>';
        } else {
            stars += '<i class="far fa-star text-warning"></i>';
        }
    }
    return stars;
}

// ========== CART SYSTEM ==========
async function addToCart(itemId) {
    if (!sessionId) {
        showLoginModal();
        showToast('Please login to add items to cart', 'warning');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/cart/add`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': sessionId
            },
            body: JSON.stringify({ item_id: itemId, quantity: 1 })
        });

        const data = await response.json();

        if (response.ok) {
            showToast(data.message, 'success');
            loadCart();

            // Animate cart icon
            const cartIcon = document.getElementById('cartIcon');
            cartIcon.classList.add('animate__animated', 'animate__tada');
            setTimeout(() => {
                cartIcon.classList.remove('animate__animated', 'animate__tada');
            }, 1000);
        } else {
            showToast(data.error, 'danger');
        }
    } catch (error) {
        console.error('Add to cart error:', error);
        showToast('Failed to add to cart', 'danger');
    }
}

async function updateCartQuantity(itemId, change) {
    if (!sessionId) return;

    try {
        const response = await fetch(`${API_BASE}/cart/update`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': sessionId
            },
            body: JSON.stringify({ item_id: itemId, quantity: change })
        });

        if (response.ok) {
            loadCart();
            showToast('Cart updated', 'success');
        }
    } catch (error) {
        console.error('Update cart error:', error);
    }
}

async function removeFromCart(itemId) {
    if (!sessionId) return;

    if (!confirm('Remove this item from cart?')) return;

    try {
        const response = await fetch(`${API_BASE}/cart/remove`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': sessionId
            },
            body: JSON.stringify({ item_id: itemId })
        });

        if (response.ok) {
            showToast('Item removed from cart', 'success');
            loadCart();
        }
    } catch (error) {
        console.error('Remove from cart error:', error);
    }
}

async function loadCart() {
    if (!sessionId) {
        updateCartCount(0);
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/cart`, {
            headers: { 'Authorization': sessionId }
        });

        if (response.ok) {
            const cartData = await response.json();
            currentCart = cartData.items || [];
            updateCartCount(cartData.count || 0);

            const container = document.getElementById('cartItems');
            const emptyCart = document.querySelector('.empty-cart');
            const cartFooter = document.querySelector('.cart-footer');

            if (currentCart.length > 0) {
                if (emptyCart) emptyCart.style.display = 'none';
                if (cartFooter) cartFooter.style.display = 'block';

                let html = '';
                currentCart.forEach(item => {
                    const subtotal = item.price * item.quantity;
                    html += `
                                <div class="cart-item">
                                    <div class="cart-item-img">
                                        <img src="${item.image}" alt="${item.name}">
                                    </div>
                                    <div class="cart-item-details">
                                        <div class="cart-item-name">${item.name}</div>
                                        <div class="cart-item-price">Rs. ${item.price} × ${item.quantity}</div>
                                        <div class="cart-item-subtotal">Rs. ${subtotal}</div>
                                        <div class="cart-item-actions">
                                            <button class="quantity-btn" onclick="updateCartQuantity(${item.id}, ${item.quantity - 1})">
                                                <i class="fas fa-minus"></i>
                                            </button>
                                            <span class="quantity-display">${item.quantity}</span>
                                            <button class="quantity-btn" onclick="updateCartQuantity(${item.id}, ${item.quantity + 1})">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                            <button class="remove-item" onclick="removeFromCart(${item.id})">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            `;
                });

                container.innerHTML = html;

                // Update total
                document.querySelector('.total-amount').textContent = `Rs. ${cartData.total.toFixed(2)}`;
            } else {
                if (emptyCart) emptyCart.style.display = 'block';
                if (cartFooter) cartFooter.style.display = 'none';
                container.innerHTML = '';
            }
        }
    } catch (error) {
        console.error('Error loading cart:', error);
    }
}

function updateCartCount(count) {
    const cartCount = document.querySelector('.cart-count');
    if (cartCount) {
        cartCount.textContent = count;
        cartCount.style.display = count > 0 ? 'inline-flex' : 'none';
    }
}

function openCart() {
    if (!sessionId) {
        showLoginModal();
        return;
    }

    loadCart();
    document.getElementById('sideCart').classList.add('open');
    document.getElementById('cartOverlay').classList.add('active');
}

function closeCart() {
    document.getElementById('sideCart').classList.remove('open');
    document.getElementById('cartOverlay').classList.remove('active');
}

// ========== CHECKOUT SYSTEM ==========
function openCheckoutModal() {
    if (currentCart.length === 0) {
        showToast('Your cart is empty', 'warning');
        return;
    }

    // Calculate subtotal
    const subtotal = currentCart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    // Update modal values
    document.getElementById('checkoutSubtotal').textContent = `Rs. ${subtotal.toFixed(2)}`;
    document.getElementById('checkoutTax').textContent = `Rs. ${(subtotal * 0.16).toFixed(2)}`;
    document.getElementById('checkoutDelivery').textContent = 'Rs. 0.00';
    document.getElementById('checkoutDiscount').textContent = 'Rs. 0.00';

    // Update balance
    if (currentUser) {
        document.getElementById('checkoutBalance').textContent = `Rs. ${currentUser.balance.toFixed(2)}`;
    }

    // Reset offer
    currentOffer = null;
    appliedDiscount = 0;
    document.getElementById('offerCode').value = '';
    document.getElementById('offerStatus').textContent = '';

    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('checkoutModal'));
    modal.show();
}

async function applyOffer() {
    const code = document.getElementById('offerCode').value.trim();
    if (!code) {
        showToast('Please enter offer code', 'warning');
        return;
    }

    const subtotal = currentCart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    try {
        const response = await fetch(`${API_BASE}/offers/validate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ code, subtotal })
        });

        const data = await response.json();

        if (response.ok) {
            if (data.valid) {
                currentOffer = data.offer;
                appliedDiscount = data.discount;

                // Update UI
                document.getElementById('offerStatus').innerHTML =
                    `<span class="text-success"><i class="fas fa-check-circle"></i> ${data.offer.title} applied!</span>`;
                document.getElementById('checkoutDiscount').textContent = `-Rs. ${appliedDiscount.toFixed(2)}`;

                // Update total
                updateCheckoutTotal();

                showToast(`Offer applied! Discount: Rs. ${appliedDiscount.toFixed(2)}`, 'success');
            } else {
                document.getElementById('offerStatus').innerHTML =
                    `<span class="text-danger"><i class="fas fa-times-circle"></i> ${data.message}</span>`;
                showToast(data.message, 'danger');
            }
        }
    } catch (error) {
        console.error('Apply offer error:', error);
        showToast('Failed to validate offer', 'danger');
    }
}

function updateCheckoutTotal() {
    const subtotal = currentCart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.16;
    const deliveryCharge = document.querySelector('input[name="deliveryOption"]:checked').value === 'delivery' ? 50 : 0;
    const total = subtotal + tax + deliveryCharge - appliedDiscount;

    document.getElementById('checkoutTotal').textContent = `Rs. ${total.toFixed(2)}`;
}

async function placeOrder() {
    const deliveryOption = document.querySelector('input[name="deliveryOption"]:checked').value;
    const deliveryAddress = deliveryOption === 'delivery' ?
        document.getElementById('deliveryAddress').value.trim() : '';

    if (deliveryOption === 'delivery' && !deliveryAddress) {
        showToast('Please enter delivery address', 'warning');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/orders/create`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': sessionId
            },
            body: JSON.stringify({
                delivery_option: deliveryOption,
                delivery_address: deliveryAddress,
                offer_code: currentOffer ? currentOffer.code : ''
            })
        });

        const data = await response.json();

        if (response.ok) {
            // Close modals
            const checkoutModal = bootstrap.Modal.getInstance(document.getElementById('checkoutModal'));
            if (checkoutModal) checkoutModal.hide();
            closeCart();

            // Show success
            showToast(`🎉 Order placed successfully! Order #${data.order_number}`, 'success');

            // Update UI
            loadCart();
            loadUserOrders();
            loadUserProfile(); // Update balance

            // Show tracking
            setTimeout(() => {
                document.querySelector('#track').scrollIntoView({ behavior: 'smooth' });
                loadTracking();
            }, 1000);

        } else {
            showToast(data.error || 'Order failed', 'danger');
        }
    } catch (error) {
        showToast('Order placement failed', 'danger');
    }
}

// ========== OFFERS ==========
async function loadOffers() {
    try {
        const response = await fetch(`${API_BASE}/offers`);
        const offers = await response.json();

        const container = document.getElementById('offersGrid');
        if (!container) return;

        container.innerHTML = '';

        offers.forEach(offer => {
            const col = document.createElement('div');
            col.className = 'col-md-4 mb-4';

            col.innerHTML = `
                        <div class="offer-card animate__animated animate__fadeInUp">
                            <div class="offer-badge">${offer.discount_type === 'percentage' ? `${offer.value}% OFF` : 'SPECIAL OFFER'}</div>
                            <h5 class="offer-title">${offer.title}</h5>
                            <p class="offer-description">${offer.description}</p>
                            <div class="offer-details">
                                <div class="offer-code">
                                    <i class="fas fa-tag me-2"></i> <strong>${offer.code}</strong>
                                </div>
                                <div class="offer-minimum">
                                    <i class="fas fa-shopping-cart me-2"></i> Min: Rs. ${offer.min_order}
                                </div>
                                <div class="offer-validity">
                                    <i class="fas fa-calendar me-2"></i> Valid until: ${offer.valid_until}
                                </div>
                            </div>
                            <button class="btn btn-sm btn-outline-primary mt-3" onclick="copyOfferCode('${offer.code}')">
                                <i class="fas fa-copy"></i> Copy Code
                            </button>
                        </div>
                    `;

            container.appendChild(col);
        });
    } catch (error) {
        console.error('Error loading offers:', error);
    }
}

function copyOfferCode(code) {
    navigator.clipboard.writeText(code)
        .then(() => showToast(`Code "${code}" copied to clipboard!`, 'success'))
        .catch(() => showToast('Failed to copy code', 'danger'));
}

// ========== ORDER TRACKING ==========
async function loadUserOrders() {
    if (!sessionId) return;

    try {
        const response = await fetch(`${API_BASE}/orders`, {
            headers: { 'Authorization': sessionId }
        });

        if (response.ok) {
            const orders = await response.json();
            const container = document.getElementById('ordersList');

            if (!container) return;

            if (orders.length > 0) {
                let html = '';
                orders.slice(0, 5).forEach(order => {
                    const date = new Date(order.created_at).toLocaleDateString();
                    const time = new Date(order.created_at).toLocaleTimeString();

                    html += `
                                <div class="order-card mb-3">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-start mb-3">
                                                <div>
                                                    <h6 class="mb-1">${order.order_number}</h6>
                                                    <small class="text-muted">${date} ${time}</small>
                                                </div>
                                                <div class="text-end">
                                                    <div class="order-status ${order.status}">${order.status}</div>
                                                    <div class="order-total mt-1">Rs. ${order.total.toFixed(2)}</div>
                                                </div>
                                            </div>
                                            <div class="order-items mb-3">
                                                ${order.items.slice(0, 2).map(item =>
                        `<span class="badge bg-light text-dark me-1 mb-1">${item.name} × ${item.quantity}</span>`
                    ).join('')}
                                                ${order.items.length > 2 ?
                            `<span class="badge bg-secondary">+${order.items.length - 2} more</span>` : ''}
                                            </div>
                                            <div class="order-actions">
                                                <button class="btn btn-sm btn-outline-primary" onclick="trackOrder(${order.id})">
                                                    <i class="fas fa-map-marker-alt"></i> Track
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `;
                });

                container.innerHTML = html;
            } else {
                container.innerHTML = `
                            <div class="text-center py-4">
                                <i class="fas fa-receipt fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No orders yet</p>
                                <button class="btn btn-outline-primary" onclick="document.querySelector('#menu').scrollIntoView()">
                                    <i class="fas fa-utensils"></i> Order Now
                                </button>
                            </div>
                        `;
            }
        }
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

async function trackOrder(orderId) {
    if (!sessionId) return;

    try {
        const response = await fetch(`${API_BASE}/orders/${orderId}/track`, {
            headers: { 'Authorization': sessionId }
        });

        if (response.ok) {
            const order = await response.json();

            // Update tracking UI
            const container = document.getElementById('trackingDetails');
            if (container) {
                const progress = order.progress || 0;
                const status = order.current_status || order.status;

                container.innerHTML = `
                            <div class="tracking-card">
                                <div class="tracking-header d-flex justify-content-between align-items-center mb-4">
                                    <h5>${order.order_number}</h5>
                                    <div class="tracking-status ${order.status}">${status}</div>
                                </div>
                                
                                <div class="tracking-progress">
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: ${progress}%"></div>
                                    </div>
                                    <div class="progress-steps">
                                        <div class="step ${progress >= 0 ? 'active' : ''}">
                                            <div class="step-icon">📝</div>
                                            <span>Ordered</span>
                                        </div>
                                        <div class="step ${progress >= 25 ? 'active' : ''}">
                                            <div class="step-icon">✅</div>
                                            <span>Confirmed</span>
                                        </div>
                                        <div class="step ${progress >= 50 ? 'active' : ''}">
                                            <div class="step-icon">👨‍🍳</div>
                                            <span>Preparing</span>
                                        </div>
                                        <div class="step ${progress >= 75 ? 'active' : ''}">
                                            <div class="step-icon">📦</div>
                                            <span>Ready</span>
                                        </div>
                                        <div class="step ${progress >= 100 ? 'active' : ''}">
                                            <div class="step-icon">${order.delivery_option === 'delivery' ? '🚚' : '✅'}</div>
                                            <span>${order.delivery_option === 'delivery' ? 'Delivered' : 'Picked Up'}</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="tracking-info mt-5">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h6>Order Details</h6>
                                            <p><strong>Delivery:</strong> ${order.delivery_option}</p>
                                            <p><strong>Address:</strong> ${order.delivery_address}</p>
                                            <p><strong>Estimated Time:</strong> ${new Date(order.estimated_time).toLocaleTimeString()}</p>
                                            <p><strong>Total:</strong> Rs. ${order.total.toFixed(2)}</p>
                                        </div>
                                        <div class="col-md-6">
                                            <h6>Recent Updates</h6>
                                            <div class="updates-list">
                                                ${order.updates.slice(-3).reverse().map(update => `
                                                    <div class="update-item mb-2">
                                                        <div class="update-time">${new Date(update.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                                                        <div class="update-message">${update.message}</div>
                                                        ${update.updated_by ? `<small class="text-muted">by ${update.updated_by}</small>` : ''}
                                                    </div>
                                                `).join('')}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;

                // Scroll to tracking section
                document.querySelector('#track').scrollIntoView({ behavior: 'smooth' });
            }

            showToast('Tracking loaded', 'success');
        }
    } catch (error) {
        console.error('Error tracking order:', error);
    }
}

async function loadTracking() {
    if (!sessionId) return;

    // Get latest order
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            headers: { 'Authorization': sessionId }
        });

        if (response.ok) {
            const orders = await response.json();
            const container = document.getElementById('trackingDetails');

            if (orders.length > 0) {
                trackOrder(orders[0].id);
            } else {
                container.innerHTML = `
                            <div class="text-center py-5">
                                <i class="fas fa-map-marker-alt fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No active orders to track</p>
                                <button class="btn btn-outline-primary" onclick="document.querySelector('#menu').scrollIntoView()">
                                    <i class="fas fa-utensils"></i> Order Now
                                </button>
                            </div>
                        `;
            }
        }
    } catch (error) {
        console.error('Error loading tracking:', error);
    }
}

// ========== ADMIN DASHBOARD ==========
async function loadAdminDashboard() {
    if (!sessionId || !currentUser || currentUser.role !== 'admin') return;

    try {
        const [statsResponse, ordersResponse] = await Promise.all([
            fetch(`${API_BASE}/admin/stats`, { headers: { 'Authorization': sessionId } }),
            fetch(`${API_BASE}/admin/orders`, { headers: { 'Authorization': sessionId } })
        ]);

        if (statsResponse.ok) {
            const stats = await statsResponse.json();

            // Update stats cards
            document.getElementById('totalOrders').textContent = stats.total_orders;
            document.getElementById('totalRevenue').textContent = `Rs. ${stats.total_revenue.toFixed(2)}`;
            document.getElementById('todayOrders').textContent = stats.today_orders;
            document.getElementById('todayRevenue').textContent = `Rs. ${stats.today_revenue.toFixed(2)}`;
            document.getElementById('pendingOrders').textContent = stats.pending_orders;
            document.getElementById('activeUsers').textContent = stats.active_users;

            // Update popular categories
            const categoriesContainer = document.getElementById('popularCategories');
            if (categoriesContainer) {
                let categoriesHtml = '';
                for (const [category, count] of Object.entries(stats.popular_categories)) {
                    categoriesHtml += `
                                <div class="category-stat">
                                    <span class="category-name">${category}</span>
                                    <span class="category-count">${count} orders</span>
                                </div>
                            `;
                }
                categoriesContainer.innerHTML = categoriesHtml;
            }
        }

        if (ordersResponse.ok) {
            const orders = await ordersResponse.json();
            const container = document.getElementById('adminOrdersList');

            if (container && orders.length > 0) {
                let html = `
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Order #</th>
                                            <th>Customer</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Delivery</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                        `;

                orders.slice(0, 10).forEach(order => {
                    html += `
                                <tr>
                                    <td><strong>${order.order_number}</strong></td>
                                    <td>${order.username}</td>
                                    <td>Rs. ${order.total.toFixed(2)}</td>
                                    <td>
                                        <span class="order-status ${order.status}">${order.status}</span>
                                    </td>
                                    <td>${order.delivery_option}</td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-primary" onclick="adminUpdateOrder(${order.id})">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-outline-info" onclick="trackOrder(${order.id})">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            `;
                });

                html += '</tbody></table></div>';
                container.innerHTML = html;
            }
        }
    } catch (error) {
        console.error('Error loading admin dashboard:', error);
    }
}

async function adminUpdateOrder(orderId) {
    const status = prompt('Enter new status (pending/confirmed/preparing/ready/delivered/picked_up):', 'ready');
    if (!status) return;

    const message = prompt('Enter update message (optional):', '');

    try {
        const response = await fetch(`${API_BASE}/orders/${orderId}/update-status`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': sessionId
            },
            body: JSON.stringify({
                order_id: orderId,
                status: status,
                message: message
            })
        });

        if (response.ok) {
            showToast(`Order status updated to ${status}`, 'success');
            loadAdminDashboard();
            loadKitchenDashboard(); // Refresh kitchen view too
        } else {
            const data = await response.json();
            showToast(data.error || 'Update failed', 'danger');
        }
    } catch (error) {
        console.error('Error updating order:', error);
        showToast('Update failed', 'danger');
    }
}

// ========== KITCHEN DASHBOARD ==========
async function loadKitchenDashboard() {
    if (!sessionId || !currentUser || currentUser.role !== 'kitchen_staff') return;

    try {
        const response = await fetch(`${API_BASE}/kitchen/orders`, {
            headers: { 'Authorization': sessionId }
        });

        if (response.ok) {
            const orders = await response.json();
            const container = document.getElementById('kitchenOrdersList');

            if (container) {
                if (orders.length > 0) {
                    let html = '';
                    orders.forEach(order => {
                        const itemsList = order.items.slice(0, 3).map(item =>
                            `<span class="badge bg-light text-dark me-1 mb-1">${item.name} × ${item.quantity}</span>`
                        ).join('');

                        html += `
                                    <div class="kitchen-order-card">
                                        <div class="kitchen-order-header d-flex justify-content-between align-items-start mb-3">
                                            <div>
                                                <h6>${order.order_number}</h6>
                                                <small class="text-muted">${new Date(order.created_at).toLocaleTimeString()}</small>
                                                <div class="mt-2">${itemsList}</div>
                                                ${order.items.length > 3 ?
                                `<small class="text-muted">+${order.items.length - 3} more items</small>` : ''}
                                            </div>
                                            <div class="text-end">
                                                <div class="kitchen-order-status ${order.status}">${order.status}</div>
                                                <div class="kitchen-order-time mt-1">${order.delivery_option === 'delivery' ? '🚚 Delivery' : '✅ Pickup'}</div>
                                            </div>
                                        </div>
                                        <div class="kitchen-order-actions">
                                            ${getKitchenActions(order.id, order.status)}
                                        </div>
                                    </div>
                                `;
                    });

                    container.innerHTML = html;
                } else {
                    container.innerHTML = `
                                <div class="text-center py-5">
                                    <i class="fas fa-utensils fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">No pending orders</p>
                                </div>
                            `;
                }
            }
        }
    } catch (error) {
        console.error('Error loading kitchen dashboard:', error);
    }
}

function getKitchenActions(orderId, currentStatus) {
    const statusFlow = {
        'pending': ['confirmed'],
        'confirmed': ['preparing'],
        'preparing': ['ready'],
        'ready': ['delivered', 'picked_up']
    };

    const nextStatuses = statusFlow[currentStatus] || [];

    let buttons = '';
    nextStatuses.forEach(status => {
        const buttonText = status === 'delivered' ? 'Mark as Delivered' :
            status === 'picked_up' ? 'Mark as Picked Up' :
                status === 'ready' ? 'Mark as Ready' :
                    status === 'preparing' ? 'Start Preparing' : 'Confirm Order';

        const buttonClass = status === 'delivered' ? 'success' :
            status === 'picked_up' ? 'primary' : 'warning';

        buttons += `
                    <button class="btn btn-sm btn-${buttonClass} me-2" onclick="kitchenUpdateOrder(${orderId}, '${status}')">
                        ${buttonText}
                    </button>
                `;
    });

    return buttons || '<span class="text-muted">No actions available</span>';
}

async function kitchenUpdateOrder(orderId, status) {
    const message = prompt('Enter update message (optional):', '');

    try {
        const response = await fetch(`${API_BASE}/orders/${orderId}/update-status`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': sessionId
            },
            body: JSON.stringify({
                order_id: orderId,
                status: status,
                message: message
            })
        });

        if (response.ok) {
            const messages = {
                'delivered': '🎉 Order marked as delivered! It\'s at their door!',
                'picked_up': '✅ Order picked up successfully!',
                'ready': '📦 Order is ready for pickup/delivery!',
                'preparing': '👨‍🍳 Started preparing the order!',
                'confirmed': '✅ Order confirmed and queued!'
            };

            showToast(messages[status] || 'Order updated', 'success');
            loadKitchenDashboard();
        } else {
            const data = await response.json();
            showToast(data.error || 'Update failed', 'danger');
        }
    } catch (error) {
        console.error('Error updating order:', error);
        showToast('Update failed', 'danger');
    }
}

// ========== USER PROFILE ==========
function loadUserProfile() {
    if (!currentUser) return;

    // Update profile display
    document.getElementById('profileName').textContent = currentUser.username;
    document.getElementById('profileEmail').textContent = currentUser.email;
    document.getElementById('profileRole').textContent = currentUser.role.toUpperCase();
    document.getElementById('profileBalance').textContent = `Rs. ${currentUser.balance.toFixed(2)}`;
    document.getElementById('profilePhone').textContent = currentUser.phone || 'Not set';
    document.getElementById('profileAddress').textContent = currentUser.address || 'Not set';
    document.getElementById('profileAvatar').textContent = currentUser.profile_pic || '👤';

    // Set badge
    const badgeEl = document.getElementById('profileBadge');
    if (badgeEl) {
        let badge = 'New Member';
        let badgeClass = 'secondary';

        if (currentUser.role === 'admin') {
            badge = '👑 Administrator';
            badgeClass = 'danger';
        } else if (currentUser.role === 'teacher') {
            badge = '👨‍🏫 Faculty Member';
            badgeClass = 'info';
        } else if (currentUser.role === 'kitchen_staff') {
            badge = '👨‍🍳 Kitchen Staff';
            badgeClass = 'warning';
        } else if (currentUser.balance > 1000) {
            badge = '⭐ Premium Member';
            badgeClass = 'success';
        }

        badgeEl.textContent = badge;
        badgeEl.className = `badge bg-${badgeClass}`;
    }

    // Update form fields
    document.getElementById('editPhone').value = currentUser.phone || '';
    document.getElementById('editAddress').value = currentUser.address || '';
}

async function updateProfile() {
    const phone = document.getElementById('editPhone').value.trim();
    const address = document.getElementById('editAddress').value.trim();

    try {
        const response = await fetch(`${API_BASE}/user/update-profile`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': sessionId
            },
            body: JSON.stringify({ phone, address })
        });

        if (response.ok) {
            const data = await response.json();
            currentUser = data.user;
            localStorage.setItem('campus_user', JSON.stringify(currentUser));
            loadUserProfile();
            showToast('Profile updated successfully', 'success');

            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('profileModal'));
            if (modal) modal.hide();
        } else {
            showToast('Profile update failed', 'danger');
        }
    } catch (error) {
        console.error('Error updating profile:', error);
        showToast('Profile update failed', 'danger');
    }
}

function addFundsAmount(amount) {
    document.getElementById('customAmount').value = amount;
    addCustomFunds();
}

async function addCustomFunds() {
    const amount = parseFloat(document.getElementById('customAmount').value);

    if (!amount || amount <= 0 || isNaN(amount)) {
        showToast('Invalid amount', 'warning');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/user/balance/add`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': sessionId
            },
            body: JSON.stringify({ amount })
        });

        if (response.ok) {
            const data = await response.json();
            currentUser.balance = data.new_balance;
            localStorage.setItem('campus_user', JSON.stringify(currentUser));
            loadUserProfile();

            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('addFundsModal'));
            if (modal) modal.hide();

            showToast(data.message, 'success');
        } else {
            showToast('Failed to add funds', 'danger');
        }
    } catch (error) {
        console.error('Error adding funds:', error);
        showToast('Failed to add funds', 'danger');
    }
}

// ========== UTILITY FUNCTIONS ==========
function showLoading() {
    const preloader = document.getElementById('preloader');
    if (preloader) {
        preloader.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function hideLoading() {
    const preloader = document.getElementById('preloader');
    if (preloader) {
        preloader.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

function showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(container);
    }

    const toastId = 'toast-' + Date.now();
    const toastHtml = `
                <div id="${toastId}" class="toast" role="alert">
                    <div class="toast-header bg-${type} text-white">
                        <i class="fas fa-${getToastIcon(type)} me-2"></i>
                        <strong class="me-auto">${type.charAt(0).toUpperCase() + type.slice(1)}</strong>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                    </div>
                    <div class="toast-body">${message}</div>
                </div>
            `;

    container.insertAdjacentHTML('beforeend', toastHtml);

    const toastEl = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastEl, { delay: 3000 });
    toast.show();

    toastEl.addEventListener('hidden.bs.toast', function () {
        toastEl.remove();
    });
}

function getToastIcon(type) {
    switch (type) {
        case 'success': return 'check-circle';
        case 'warning': return 'exclamation-triangle';
        case 'danger': return 'times-circle';
        default: return 'info-circle';
    }
}

function toggleFavorite(itemId) {
    showToast('Added to favorites!', 'success');
}

// Initialize the application
console.log('✨ CampusHub Premium Cafeteria - All Features Working');
console.log('🚀 Features: Real Cart, Order Tracking, Discounts, Role-based Dashboards');